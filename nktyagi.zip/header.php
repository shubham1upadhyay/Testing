<body>
<main>
<!--header start-->
<header>
	<div class="header-center">
		
		 <nav class="navbar navbar-default navbar-static-top">
        <div class="container-fluid">

          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#"><img class="mylogo" src="images/logo.png"></a>
          </div>
 
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav nkmenu navbar-right">
              <li><a href="index.php">HOME   </a></li>
              <li><a href="about.php"> about</a></li>
			  <li><a href="services.php"> Services</a></li>
              <!--li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Download forms <i class="fa fa-angle-down fa-lg" aria-hidden="true"></i></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="https://www.tin-nsdl.com/download/pan/Form49A.pdf"> pan form</a></li>
                    <li><a href="https://www.tin-nsdl.com/download/tan/Form49b_26062013.pdf"> tan form</a></li>
                    <li><a href="https://www.tin-nsdl.com/download/pan/PAN-CR-FORM.pdf"> pan correction form </a></li>
                  
                    
                  </ul>
                </li-->
			  <!--li><a href="clients.php"> clients </a></li-->
			   <li><a href="download.php"> download forms</a></li>
			  <li><a href="contact.php"> contact  </a></li> 
			   <li><img class="nkpic" src="images/nkpic.jpg"></li> 
			 			  
               
            </ul>
        
          
          </div> 
        </div> 
      </nav>
      
		
	</div>
</header>
<!--header end-->