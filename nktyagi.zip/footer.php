<!--footer start-->
<footer>
	<div class="footer-center">
		<div class="container-fluid">
			 <div class="row" style="overflow:hidden">  
            	<div class=" col-xs-12 col-sm-6 col-md-3 col-lg-3 wow fadeInDown data-wow-duration='1s' data-wow-delay='0.2s'" style="visibility: visible; animation-name: fadeInDown;">	
					<h2>quick links</h2>
					<ul class="footer-ul">
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> home </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> about  </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> services </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> clients </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> contact </a></li>
					</ul>
				</div>
				
				<div class=" col-xs-12 col-sm-6 col-md-3 col-lg-3 wow fadeInDown data-wow-duration='1s' data-wow-delay='0.2s'" style="visibility: visible; animation-name: fadeInDown;">	
					<h2>Our Services</h2>
					<ul class="footer-ul">
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Income tax</a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Sales tax  </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Tally accounting </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Data entry </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> T.D.S </a></li>
					</ul>
				</div>
				
				<div class=" col-xs-12 col-sm-6 col-md-3 col-lg-3 wow fadeInDown data-wow-duration='1s' data-wow-delay='0.2s'" style="visibility: visible; animation-name: fadeInDown;">	
					<h2>Our Services</h2>
					<ul class="footer-ul">
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Excise Duty </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Service Tax </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> Tax Consultant </a></li>
						<li><a href="#"><i class="fa fa-angle-right footeri" aria-hidden="true"></i> E.S.I & P.F </a></li>
					</ul>
				</div>
				
				<div class=" col-xs-12 col-sm-6 col-md-3 col-lg-3 wow fadeInDown data-wow-duration='1s' data-wow-delay='0.2s'" style="visibility: visible; animation-name: fadeInDown;">	
					<h2>Contact us</h2>
					 <p><i class="fa fa-location-arrow footeri" aria-hidden="true"></i> 16, Prem Enclave, Opp. D.P.S.School, Near Kailash Hospital, Meerut Road, Ghaziabad</p>
					 <p><i class="fa fa-envelope-o footeri" aria-hidden="true"></i> navintyagi1974@gmail.com , Navintyagi963@gmail.com</p>
					 <p><i class="fa fa-phone footeri" aria-hidden="true"></i>  +91-9999924828</p>
				</div>
				
			</div>	
		</div>
	</div>
	<div class="footer-center1">
		<div class="footer-center1-center">
			<div class="container-fluid">
			 <div class="row" style="overflow:hidden">  
            	<div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12 wow fadeInDown data-wow-duration='1s' data-wow-delay='0.2s'" style="visibility: visible; animation-name: fadeInDown;">	
					<p>Copyright © 2016 NK Tyagi & Associates , All Rights Reserved ---------- Powered by :<a href="http://intensivecreations.com" target="_blank"> IntensiveCreations.com </a></p>
				</div>
				 
			</div>
		</div>
	</div>
</div>	
</footer>	
<!--footer end-->
</main>
</body>
</html>